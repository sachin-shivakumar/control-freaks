declare module 'speech-rule-engine' {
  export function engineReady(): boolean;
}
