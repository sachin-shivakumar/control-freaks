import './lib/lazy.js';

import {LazyHandler} from '../../../../js/ui/lazy/LazyHandler.js';

if (MathJax.startup) {
  MathJax.startup.extendHandler(handler => LazyHandler(handler));
}
