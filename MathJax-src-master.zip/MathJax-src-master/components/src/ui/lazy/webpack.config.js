const PACKAGE = require('../../../webpack.common.js');

module.exports = PACKAGE(
  'ui/lazy',                          // the package to build
  '../../../../js',                   // location of the MathJax js library
  [                                   // packages to link to
    'components/src/core/lib'
  ],
  __dirname                           // our directory
);
