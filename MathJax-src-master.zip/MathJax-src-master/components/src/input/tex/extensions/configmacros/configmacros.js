import './lib/configmacros.js';
