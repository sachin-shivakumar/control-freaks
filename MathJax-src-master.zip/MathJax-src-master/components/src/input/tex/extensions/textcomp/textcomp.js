import './lib/textcomp.js';
