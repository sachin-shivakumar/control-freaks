const PACKAGE = require('../../../../../webpack.common.js');

module.exports = PACKAGE(
  'empheq',            // the package to build
  '../../../../../js', // location of the compiled js files
  [                    // packages to link to
    'components/src/input/tex-base/lib',
    'components/src/core/lib'
  ],
  __dirname            // our directory
);

