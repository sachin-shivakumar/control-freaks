import './lib/colortbl.js';
