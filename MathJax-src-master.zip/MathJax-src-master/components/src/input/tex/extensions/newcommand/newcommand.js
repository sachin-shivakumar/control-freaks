import './lib/newcommand.js';
