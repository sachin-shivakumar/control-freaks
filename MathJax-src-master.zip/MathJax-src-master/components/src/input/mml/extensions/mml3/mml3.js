import './lib/mml3.js';

import {Mml3Handler} from '../../../../../../js/input/mathml/mml3/mml3.js';

if (MathJax.startup) {
  MathJax.startup.extendHandler(handler => Mml3Handler(handler));
}
