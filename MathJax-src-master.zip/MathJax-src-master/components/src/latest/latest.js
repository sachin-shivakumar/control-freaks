import {loadLatest} from '../../../js/components/latest.js';

loadLatest();
